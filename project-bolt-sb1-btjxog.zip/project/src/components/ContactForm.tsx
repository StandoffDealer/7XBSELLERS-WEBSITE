import React from 'react';
import { useForm } from 'react-hook-form';
import { Button } from './ui/Button';

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
}

export function ContactForm() {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>();

  const onSubmit = (data: FormData) => {
    console.log(data);
    // Handle form submission
  };

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-16 text-gradient">
          Contact Us
        </h2>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">First Name</label>
              <input
                {...register('firstName', { required: true })}
                className="w-full bg-transparent border-2 border-white/20 rounded-lg px-4 py-2 focus:border-yellow-400 focus:outline-none"
              />
              {errors.firstName && (
                <p className="mt-1 text-sm text-red-400">First name is required</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Last Name</label>
              <input
                {...register('lastName', { required: true })}
                className="w-full bg-transparent border-2 border-white/20 rounded-lg px-4 py-2 focus:border-yellow-400 focus:outline-none"
              />
              {errors.lastName && (
                <p className="mt-1 text-sm text-red-400">Last name is required</p>
              )}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              {...register('email', {
                required: true,
                pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i
              })}
              className="w-full bg-transparent border-2 border-white/20 rounded-lg px-4 py-2 focus:border-yellow-400 focus:outline-none"
            />
            {errors.email && (
              <p className="mt-1 text-sm text-red-400">Valid email is required</p>
            )}
          </div>
          <Button type="submit" className="w-full">
            Send Message
          </Button>
        </form>
      </div>
    </section>
  );
}