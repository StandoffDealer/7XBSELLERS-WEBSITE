import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
  className?: string;
  onClick?: () => void;
}

export function Button({ children, variant = 'primary', className = '', onClick }: ButtonProps) {
  const baseStyles = 'px-4 py-2 rounded-[20px] font-medium transition-all duration-300 relative overflow-hidden';
  const variants = {
    primary: 'bg-transparent text-white border-2 border-white hover:bg-white hover:text-black shadow-[0_0_10px_rgba(255,255,255,0.2)] hover:shadow-[0_0_20px_rgba(255,255,255,0.4)]',
    secondary: 'bg-transparent text-white border border-white/20 hover:border-white hover:shadow-[0_0_10px_rgba(255,255,255,0.2)]'
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${className}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}