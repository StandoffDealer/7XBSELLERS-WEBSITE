import React from 'react';
import { Button } from './ui/Button';

export function ProductFeatures() {
  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-bl from-yellow-400/10 to-white/5 rounded-3xl" />
            <img
              src="https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80"
              alt="OFF-WHITE Bag Details"
              className="rounded-3xl shadow-2xl w-full object-cover"
            />
          </div>
          <div className="space-y-8">
            <h2 className="text-4xl font-bold text-gradient">
              Crafted for Excellence
            </h2>
            <p className="text-xl text-gray-300 leading-relaxed">
              Each OFF-WHITE bag is meticulously crafted with premium materials and iconic industrial design elements. 
              Experience unmatched quality and style that sets you apart from the crowd.
            </p>
            <ul className="space-y-4 text-gray-300">
              <li className="flex items-center">
                <span className="w-2 h-2 bg-yellow-400 rounded-full mr-3"></span>
                Premium Italian leather
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-yellow-400 rounded-full mr-3"></span>
                Signature industrial strap
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-yellow-400 rounded-full mr-3"></span>
                Authentic OFF-WHITE branding
              </li>
            </ul>
            <Button>Explore Features</Button>
          </div>
        </div>
      </div>
    </section>
  );
}