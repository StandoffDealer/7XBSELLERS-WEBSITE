import React, { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { gsap } from 'gsap';
import { useEffect, useRef } from 'react';

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const contentRefs = useRef<(HTMLDivElement | null)[]>([]);

  const questions = [
    {
      question: "What's the delivery time?",
      answer: "Standard delivery takes 3-5 business days. Express shipping options are available at checkout."
    },
    {
      question: "Is this an authentic OFF-WHITE product?",
      answer: "Yes, we only sell 100% authentic OFF-WHITE products. Each item comes with authenticity certification."
    },
    {
      question: "What's your return policy?",
      answer: "We offer a 30-day return policy for unused items in original packaging. Shipping costs for returns are covered by the customer."
    },
    {
      question: "Do you ship internationally?",
      answer: "Yes, we ship worldwide. Shipping costs and delivery times vary by location."
    }
  ];

  useEffect(() => {
    contentRefs.current.forEach((ref, index) => {
      if (ref) {
        gsap.set(ref, {
          height: index === openIndex ? 'auto' : 0,
          opacity: index === openIndex ? 1 : 0
        });
      }
    });
  }, [openIndex]);

  const toggleQuestion = (index: number) => {
    const ref = contentRefs.current[index];
    if (ref) {
      if (index === openIndex) {
        gsap.to(ref, {
          height: 0,
          opacity: 0,
          duration: 0.3,
          ease: 'power2.inOut',
          onComplete: () => setOpenIndex(null)
        });
      } else {
        if (openIndex !== null) {
          const previousRef = contentRefs.current[openIndex];
          if (previousRef) {
            gsap.to(previousRef, {
              height: 0,
              opacity: 0,
              duration: 0.3,
              ease: 'power2.inOut'
            });
          }
        }
        gsap.to(ref, {
          height: 'auto',
          opacity: 1,
          duration: 0.3,
          ease: 'power2.inOut'
        });
        setOpenIndex(index);
      }
    }
  };

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-16 text-gradient">
          Frequently Asked Questions
        </h2>
        <div className="space-y-4">
          {questions.map((item, index) => (
            <div key={index} className="glass-effect rounded-lg overflow-hidden">
              <button
                className="w-full px-6 py-4 flex items-center justify-between"
                onClick={() => toggleQuestion(index)}
              >
                <span className="text-lg font-medium">{item.question}</span>
                {openIndex === index ? (
                  <Minus className="w-5 h-5 text-yellow-400" />
                ) : (
                  <Plus className="w-5 h-5 text-yellow-400" />
                )}
              </button>
              <div
                ref={el => contentRefs.current[index] = el}
                className="overflow-hidden"
              >
                <div className="px-6 pb-4 text-gray-300">
                  {item.answer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}