import React from 'react';
import { Button } from './ui/Button';
import { Shield, CreditCard, Clock } from 'lucide-react';

export function PaymentSection() {
  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gradient mb-6">
            Secure Payment & Guarantee
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Shop with confidence knowing your transaction is protected
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {[
            {
              icon: Shield,
              title: "Secure Payment",
              description: "256-bit SSL encryption"
            },
            {
              icon: CreditCard,
              title: "Multiple Options",
              description: "All major cards accepted"
            },
            {
              icon: Clock,
              title: "30-Day Guarantee",
              description: "Money-back promise"
            }
          ].map((feature, index) => (
            <div key={index} className="glass-effect rounded-2xl p-8 text-center">
              <feature.icon className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-gray-300">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button className="text-lg px-12">
            Proceed to Payment
          </Button>
        </div>
      </div>
    </section>
  );
}