import React from 'react';
import { Star } from 'lucide-react';

export function ReviewSection() {
  const reviews = [
    {
      rating: 5,
      text: "The quality and style of this OFF-WHITE bag exceeded my expectations. Absolutely worth every penny!",
      author: "Alex Thompson",
      handle: "@alexthompson",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100&h=100"
    },
    {
      rating: 5,
      text: "Perfect size and amazing design. The attention to detail is incredible!",
      author: "Sarah Chen",
      handle: "@sarahchen",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100&h=100"
    },
    {
      rating: 5,
      text: "Best purchase I've made this year. The authenticity and style are unmatched.",
      author: "Marcus Rodriguez",
      handle: "@marcusrdz",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100&h=100"
    }
  ];

  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-16 text-gradient">
          What Our Customers Say
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="glass-effect rounded-2xl p-6 transform hover:scale-105 transition-transform duration-300">
              <div className="flex mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-300 mb-6">{review.text}</p>
              <div className="flex items-center">
                <img
                  src={review.image}
                  alt={review.author}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="ml-4">
                  <h4 className="font-medium text-white">{review.author}</h4>
                  <p className="text-sm text-yellow-400">{review.handle}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}