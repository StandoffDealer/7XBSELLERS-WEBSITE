import React from 'react';
import { ShoppingBag } from 'lucide-react';
import { Button } from './ui/Button';

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-effect">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-4">
            <ShoppingBag className="h-8 w-8 text-yellow-400" />
            <span className="text-xl font-bold text-gradient">
              7BXSELLER
            </span>
          </div>
          
          <nav className="hidden md:flex items-center">
            <div className="glass-effect rounded-full px-8 py-2">
              <ul className="flex space-x-12">
                {['Home', 'Clients', 'Payment', 'Warranty'].map((item) => (
                  <li key={item}>
                    <a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </nav>

          <div className="flex items-center space-x-8">
            <a href="#contact" className="text-gray-300 hover:text-yellow-400 transition-colors">
              Contact
            </a>
            <Button>Buy Now</Button>
          </div>
        </div>
      </div>
    </header>
  );
}