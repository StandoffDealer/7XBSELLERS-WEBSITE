import React, { useState } from 'react';
import { Button } from './ui/Button';
import { Minus, Plus } from 'lucide-react';

export function ProductPage() {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);

  const images = [
    'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=700',
    'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=600'
  ];

  const updateQuantity = (value: number) => {
    const newQuantity = Math.max(1, Math.min(99, value));
    setQuantity(newQuantity);
  };

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div className="space-y-4">
            <div className="aspect-square overflow-hidden rounded-lg">
              <img
                src={images[selectedImage]}
                alt="OFF-WHITE Pouch"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`aspect-square rounded-lg overflow-hidden border-2 transition-colors ${
                    selectedImage === index ? 'border-yellow-400' : 'border-transparent'
                  }`}
                >
                  <img src={image} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h1 className="text-2xl font-bold text-gradient">7BXSELLER</h1>
              <h2 className="text-3xl font-bold mt-2">OFF-WHITE Leather Pouch</h2>
            </div>

            <div className="space-y-2">
              <div className="flex items-center space-x-4">
                <span className="text-2xl line-through text-gray-500">€99</span>
                <span className="text-3xl font-bold">€60</span>
              </div>
              <p className="text-sm text-gray-400">Taxes included</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Size</label>
                <select className="w-full bg-transparent border-2 border-white/20 rounded-lg px-4 py-2">
                  <option value="unique">Unique Size</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Color</label>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-black border-2 border-white/20" />
                  <span className="text-sm">Black</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Quantity</label>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => updateQuantity(quantity - 1)}
                    className="p-2 border-2 border-white/20 rounded-lg"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <input
                    type="number"
                    min="1"
                    max="99"
                    value={quantity}
                    onChange={(e) => updateQuantity(parseInt(e.target.value) || 1)}
                    className="w-20 text-center bg-transparent border-2 border-white/20 rounded-lg px-4 py-2"
                  />
                  <button
                    onClick={() => updateQuantity(quantity + 1)}
                    className="p-2 border-2 border-white/20 rounded-lg"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-xl font-bold">
                Total: €{(60 * quantity).toFixed(2)}
              </p>
              <Button className="w-full">Add to Cart</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}