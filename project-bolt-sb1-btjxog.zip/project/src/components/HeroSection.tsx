import React from 'react';
import { Button } from './ui/Button';

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      <div className="starfield" />
      {[...Array(3)].map((_, i) => (
        <div key={i} className="light-beam" style={{ left: `${i * 30}%`, animationDelay: `${i * 2}s` }} />
      ))}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 relative z-10">
            <h1 className="text-6xl font-bold leading-tight text-gradient">
              Elevate Your Style with OFF-WHITE Essentials
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed">
              Experience luxury and street style fusion with our exclusive collection of OFF-WHITE accessories.
              Each piece is crafted for those who dare to stand out.
            </p>
            <div className="flex space-x-6">
              <Button className="text-lg">Shop Collection</Button>
              <Button variant="secondary" className="text-lg">Learn More</Button>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-yellow-400/10 to-white/5 rounded-3xl" />
            <img 
              src="https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80"
              alt="OFF-WHITE Bag"
              className="rounded-3xl shadow-2xl w-full object-cover transform hover:scale-105 transition-transform duration-500"
            />
          </div>
        </div>
      </div>
    </section>
  );
}