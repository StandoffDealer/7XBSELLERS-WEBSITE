import React from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ReviewSection } from './components/ReviewSection';
import { ProductPage } from './components/ProductPage';
import { FAQ } from './components/FAQ';
import { ContactForm } from './components/ContactForm';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <HeroSection />
        <ReviewSection />
        <ProductPage />
        <FAQ />
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
}